# Ai-image

This project is a free, fully-trainable AI image system using LoRA. Users can upload training data, run Colab training, and generate new images.